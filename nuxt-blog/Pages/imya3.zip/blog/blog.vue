<template>
  <div v-if="post">
    <h1>{{ post.Title }}</h1>
    <p>Author: {{ post.Author }}</p>
    <p>Category: {{ post.Category }}</p>
    <div class="content">
      <div v-for="(block, index) in post.Content" :key="index">
        <p v-if="block.type === 'paragraph'">
          <span v-for="(child, childIndex) in block.children" :key="childIndex">
            {{ child.text }}
          </span>
        </p>
      </div>
    </div>
    <p>{{ post.snippet }}</p>
  </div>
  <div v-else>
    <p>Post not found</p>
  </div>
</template>

<script setup>
const route = useRoute()

try {
  // Query by slug instead of ID
  const { data: response } = await $fetch(`http://localhost:1337/api/blog-posts?filters[slug][$eq]=${route.params.slug}`)
  const post = response.length > 0 ? response[0] : null
  
  if (!post) {
    throw createError({ statusCode: 404, statusMessage: 'Post not found' })
  }
} catch (error) {
  console.error('Error fetching post:', error)
  throw createError({ statusCode: 404, statusMessage: 'Post not found' })
}
</script>